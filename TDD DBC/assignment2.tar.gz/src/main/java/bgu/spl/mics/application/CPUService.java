package bgu.spl.mics.application;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.objects.CPU;

/*
 *sole responsibility is to update the time for the CPU
 */

public class CPUService extends MicroService {

    private CPU cpu;

    public CPUService(String name){
        super(name);

    }

    @Override
    protected void initialize() {

    }
}
