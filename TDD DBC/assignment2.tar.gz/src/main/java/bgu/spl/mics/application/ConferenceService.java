package bgu.spl.mics.application;

/*
    -collect good results
    -ask msgBug to publish them via PublishConferenceBroadcast
    -after publishing, unregister
 */

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.objects.ConfrenceInformation;

public class ConferenceService extends MicroService {
    ConfrenceInformation conference;

    public ConferenceService(ConfrenceInformation other){
        super("ConferenceService");
        conference=other;
    }

    @Override
    protected void initialize() {

    }
}
