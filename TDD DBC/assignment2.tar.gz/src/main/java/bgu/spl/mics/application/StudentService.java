package bgu.spl.mics.application;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.PublishConferenceBroadcast;
import bgu.spl.mics.application.objects.Student;
import bgu.spl.mics.example.messages.ExampleBroadcast;

/*
    * can send TrainModelEvent, TestModelEvent and PublishResultsEvent
    * must sign up for the conference publication broadcasts
 */

public class StudentService extends MicroService {

    Student std;

    public StudentService(Student student){
        super("StudentService");
        std=student;
        subscribeBroadcast(PublishConferenceBroadcast .class,message->{
            System.out.println("Student "+std.getName()+" has subscribed to conference's broadcast");
        });
    }

    @Override
    protected void initialize() {

    }
}
