package bgu.spl.mics.application;

import bgu.spl.mics.MicroService;

import java.sql.Time;

/*
    counts seconds ticks on the system for us.
    *construct with (int speed, int duration)
     for (number of milliseconds each clock tick takes, number of ticks before termintaion)
    -for every "speed" seconds from 1 to duration:
        -send msgBug to broadcast 1 second passed
    *when terminating the process do not wait for all the events to finish
    *be careful that you are not blocking the event loop of the timer
 */
public class TimeService extends MicroService  {
    private int spd;
    private int drt;

    public TimeService(int speed,int duration){
        super("TimeService");
        spd=speed;
        drt=duration;
    }

    @Override
    protected void initialize() {

    }

}
