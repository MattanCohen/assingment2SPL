package bgu.spl.mics.application;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.objects.GPU;

/*
    *responsible for handling the TrainerModelEvent and TestModelEvent
 */

public class GPUService extends MicroService {

    private GPU gpu;

    public GPUService(String name){
        super(name);
    }

    @Override
    protected void initialize() {

    }
}
